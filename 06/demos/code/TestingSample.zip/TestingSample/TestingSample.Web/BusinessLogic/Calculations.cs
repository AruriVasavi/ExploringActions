﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestingSample.Web.BusinessLogic
{
    public class Calculations
    {
        public int AddInts(int x, int y)
        {
            return x + y;
        }

        public int MultiplyInts(int x, int y)
        {
            return x * y;
        }
    }
}
